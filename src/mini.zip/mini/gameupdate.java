package mini;

public class gameupdate {
	public static void main(String[] args) {
		game gm = new game();
		gm.START();

	}
}
