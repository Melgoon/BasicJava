package report;


public class gamemain {

	public static void main(String[] args) {
		game gm = new game();
		gm.START();

	}

}
